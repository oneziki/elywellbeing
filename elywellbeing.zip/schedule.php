<!--Head Sections-->
<?php include 'templates/head.php'; ?>
<!--END Head Sections-->

<!--Nav Sections-->
<?php include 'templates/nav.php'; ?>
<!--END Nav Sections-->

<!--Header Sections-->
<?php include 'sections/header-section.php'; ?>
<!--END Header Sections-->

<!--Schedule Section-->
<?php include 'sections/schedule-section.php'; ?>
<!--END Schedule Section-->

<!--Footer Section-->
<?php include 'templates/footer.php'; ?>
<!--END Footer Section-->