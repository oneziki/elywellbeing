<!--Head Sections-->
<?php include "templates/head.php"; ?>
<!--END Head Sections-->

<!--Nav Sections-->
<?php include "templates/nav.php"; ?>
<!--END Nav Sections-->
<!--Contact Page-->

<!--Header Sections-->
<?php include "sections/header-section.php"; ?>
<!--END Header Sections-->

<?php include "sections/contact-section.php"; ?>
<!--END Contact Page-->

<!--Footer Section-->
<?php include "templates/footer.php"; ?>
<!--END Footer Section-->