<!--Head Sections-->
<?php include 'templates/head.php'; ?>
<!--END Head Sections-->

<!--Nav Sections-->
<?php include 'templates/nav.php'; ?>
<!--END Nav Sections-->

<!--Blog Section-->
<?php include "sections/blog-section.php"; ?>
<!--END Blog Section-->

<!--Footer Section-->
<?php include 'templates/footer.php'; ?>
<!--END Footer Section-->
