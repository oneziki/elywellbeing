<?php

$foo = 10;
$bar = (bool) $foo;
echo $bar;
