<section class="header">
   <div class="">
      <div class="row justify-content-center">
      <div class="col-md-12">
            <h1 class="" style="color: white !important;">Ely Wellbeing</h1>
            <h5 class="" style="padding-left: 80px; padding-right: 80px; color: white !important;">Creates Empowering Beliefs, Present Mindsets, Coherent Desires that
Attracts Your Success.</h5>
          </div>
      </div>
   </div>
</section>