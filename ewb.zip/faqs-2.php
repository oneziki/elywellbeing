<!--Head Sections-->
<?php include "templates/head.php"; ?>
<!--END Head Sections-->

<!--Nav Sections-->
<?php include "templates/nav.php"; ?>
<!--END Nav Sections-->

<!--Header Sections-->
<?php include "sections/header-section.php"; ?>
<!--END Header Sections-->
<br><br><br>
<!--FAQs Page-->
<?php include "sections/faqs.php"; ?>
<!--END FAQs Contact Page-->

<!--Footer Section-->
<?php include "templates/footer.php"; ?>
<!--END Footer Section-->