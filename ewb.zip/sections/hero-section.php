<section class="hero-wrap js-fullheight" style="background-image: url('images/bg_2.jpg');">
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-start">
          <div class="col-md-8 ftco-animate">
            <h1 class="typewrite mb-3" data-period="4000" data-type='[ "Who else wants to increase their abundance now?", "Get rid of beliefs that don’t serve you", "Here’s the fastest and easiest way to fulfil your hearts desires"]'>
              <span class="wrap"></span>
            </h1>
            <h2 class="mb-5">ELYWELLBEING</h2>
            <p><a href="about-us.php" class="btn btn-primary p-3 px-4">About Us</a></p>
          </div>
        </div>
      </div>